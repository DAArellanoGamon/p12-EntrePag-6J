import 'package:flutter/material.dart';

class PanelPantalla0429 extends StatelessWidget {
  const PanelPantalla0429({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xffff2b2b),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {},
          icon: Icon(Icons.menu, color: Colors.white),
        ),
        title: Text('Arellano Herramientas 0429',
            style: TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: Text(
          'Text',
        ),
      ),
    );
    ;
  }
}
