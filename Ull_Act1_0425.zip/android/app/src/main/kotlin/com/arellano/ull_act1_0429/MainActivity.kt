package com.arellano.ull_act1_0429

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
